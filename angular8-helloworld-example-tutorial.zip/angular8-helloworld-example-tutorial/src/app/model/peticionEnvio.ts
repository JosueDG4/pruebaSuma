export class PeticionEnvio{
 

    constructor(public val1:number, public val2:number){

    }
}